#!/bin/bash
cd ~/stocknet
pip install -r requirements.txt
streamlit run main.py --server.port=8501