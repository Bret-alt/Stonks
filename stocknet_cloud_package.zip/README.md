# StockNet Deployment README – Streamlit Cloud Ready

## Project: StockNet AI (God-tier Stock Trading Bot)
This repository contains the full deployment-ready version of StockNet – a self-evolving, sentiment-powered, technically aware, AI-driven stock trading bot with a live dashboard.

## Files Included
- main.py – The live dashboard and auto-trading interface
- train_rl_agent.py – Script for training reinforcement learning models
- stocknet_rl_agent.zip – Pretrained RL agent for buy/sell decision logic
- requirements.txt – Python package dependencies
- start.sh – Linux startup script (for VPS/EC2 use)

## Features
- AI Price Prediction using LSTM/GRU Neural Networks
- Reinforcement Learning core that evolves from trade history
- Sentiment Analysis from News headlines
- Technical Indicators: RSI, MACD, Bollinger Bands
- Auto Buy/Sell with Manual Override
- Profit Tracker & Trade Log
- Mobile Dashboard (Streamlit Cloud optimized)

## One-Click Deploy (Streamlit Cloud)
1. Create a GitHub Repo (name it `stocknet-ai` or similar)
2. Upload these files into the repo:
    - main.py
    - requirements.txt
    - stocknet_rl_agent.zip
3. Go to Streamlit Cloud and log in with GitHub
4. Click New App
    - Select your repo
    - Set main.py as the entry point
5. Click Deploy
6. Done! Your dashboard will be live at `https://<your-app-name>.streamlit.app`

## Requirements (requirements.txt)
(See requirements.txt file)

## Mobile Setup
- Open your Streamlit app link in a mobile browser
- Tap menu > Add to Home Screen
- Now you can control StockNet from your phone anytime

## License
You’re free to use, modify, and profit. Just don’t tell Wall Street we made it.

StockNet AI – Built for Total Market Domination.
